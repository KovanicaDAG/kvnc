//! Suggested alignment of kvnc treasury + emission with Protocol RFC-006 numbers.
//!
//! This file is a *skeleton* of constants + pure functions for `kvnc-staking`.
//! It does NOT import anything from kovanica-protocol.
//! Keep kvnc clean and independent.

#![cfg_attr(not(feature = "std"), no_std)]

/// Native token decimals (kvnc currently uses 9).
/// Protocol uses 8. Decide once and stick to it.
pub const DECIMALS: u8 = 9;
pub const ONE_KVNC: u128 = 1_000_000_000; // 10^9

/// Hard cap – matches both projects.
pub const TOTAL_SUPPLY: u128 = 90_200_000 * ONE_KVNC;

/// Founder premine (unlocked at genesis).
pub const FOUNDER_PREMINE: u128 = 200_000 * ONE_KVNC;

/// Treasury total (vested).
pub const TREASURY_TOTAL: u128 = 8_000_000 * ONE_KVNC;

/// Mining subsidy budget (the rest).
pub const MINING_SUBSIDY_BUDGET: u128 = TOTAL_SUPPLY - FOUNDER_PREMINE - TREASURY_TOTAL; // ≈ 82M

/// Initial reward per committed leader block.
pub const INITIAL_REWARD: u128 = 10 * ONE_KVNC;

/// Era length in committed leader blocks.
pub const ERA_LENGTH: u64 = 2_050_000;

/// Decay factor: multiply by 3/4 each era.
pub const DECAY_NUM: u128 = 3;
pub const DECAY_DEN: u128 = 4;

/// Approximate blocks per year (for linear treasury vesting).
/// Used only for the 1 M KVNC / year schedule.
pub const BLOCKS_PER_YEAR: u64 = 15_768_000; // ≈ 1 block / 2 s

/// Minimum stake to become an active validator.
pub const MIN_VALIDATOR_STAKE: u128 = 50_000 * ONE_KVNC;

/// Target active validator set size.
pub const MIN_ACTIVE_VALIDATORS: u32 = 15;
pub const MAX_ACTIVE_VALIDATORS: u32 = 21;

/// Unbonding period (in rounds / committed leaders).
pub const UNBONDING_PERIOD: u64 = 100_000;

// ---------------------------------------------------------------------------
// Pure functions
// ---------------------------------------------------------------------------

/// Reward for a given committed-leader height.
/// Geometric decay: reward = INITIAL * (3/4)^era
pub fn block_reward(committed_leader_height: u64) -> u128 {
    let era = committed_leader_height / ERA_LENGTH;
    let mut reward = INITIAL_REWARD;
    for _ in 0..era {
        reward = reward.saturating_mul(DECAY_NUM) / DECAY_DEN;
        if reward == 0 {
            break;
        }
    }
    reward
}

/// How much of the treasury is vested at the given committed-leader height.
/// Linear: 1 M KVNC per year for 8 years.
pub fn treasury_vested(committed_leader_height: u64) -> u128 {
    let years = committed_leader_height / BLOCKS_PER_YEAR;
    let vested = (years as u128).saturating_mul(1_000_000 * ONE_KVNC);
    core::cmp::min(vested, TREASURY_TOTAL)
}

/// Circulating supply estimate (premine + issued mining + vested treasury).
pub fn circulating_supply(total_mining_issued: u128, committed_leader_height: u64) -> u128 {
    let vested = treasury_vested(committed_leader_height);
    FOUNDER_PREMINE
        .saturating_add(total_mining_issued)
        .saturating_add(vested)
        .min(TOTAL_SUPPLY)
}

// ---------------------------------------------------------------------------
// Suggested state shape for kvnc-staking
// ---------------------------------------------------------------------------

#[derive(Clone, Debug, Default)]
pub struct StakingState {
    /// Total KVNC minted via leader rewards so far.
    pub total_mining_issued: u128,
    /// Current committed leader height (monotonically increasing).
    pub committed_leader_height: u64,
    /// Treasury already claimed by the treasury address.
    pub treasury_claimed: u128,
    // validator set, stakes, etc. live elsewhere
}

impl StakingState {
    /// Called by execution layer on every committed leader.
    pub fn on_leader_committed(&mut self, _leader_payout: [u8; 32]) -> u128 {
        let reward = block_reward(self.committed_leader_height);
        self.total_mining_issued = self.total_mining_issued.saturating_add(reward);
        self.committed_leader_height = self.committed_leader_height.saturating_add(1);
        reward
        // caller is responsible for crediting the leader's payout address
    }

    /// Amount the treasury can still claim.
    pub fn treasury_claimable(&self) -> u128 {
        let vested = treasury_vested(self.committed_leader_height);
        vested.saturating_sub(self.treasury_claimed)
    }

    /// Claim vested treasury (only callable by treasury authority).
    pub fn claim_treasury(&mut self, amount: u128) -> Result<(), ()> {
        let claimable = self.treasury_claimable();
        if amount > claimable {
            return Err(());
        }
        self.treasury_claimed = self.treasury_claimed.saturating_add(amount);
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// Notes for the implementer
// ---------------------------------------------------------------------------
//
// 1. Keep this file free of any kovanica-protocol imports.
// 2. Decide decimals once (9 is fine if you want more granularity).
// 3. The geometric decay + era length already match RFC-006 closely.
// 4. Treasury is linear 1 M/year instead of 8 discrete 1 M vaults –
//    functionally equivalent for most purposes and simpler.
// 5. Fee burn / fee-to-stakers can be added later as a residual mechanism
//    once mining subsidy becomes small.

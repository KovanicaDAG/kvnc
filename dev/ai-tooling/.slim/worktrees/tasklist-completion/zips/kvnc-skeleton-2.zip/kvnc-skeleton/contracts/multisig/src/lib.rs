//! Multisig wallet for kvnc
//!
//! M-of-N threshold.
//! Supports:
//!   - Propose transaction
//!   - Confirm / revoke confirmation
//!   - Execute once threshold met
//!   - Owner management (add/remove with threshold)
//!
//! Clean, minimal state machine suitable for Wasmi.

#![cfg_attr(not(feature = "std"), no_std)]

extern crate alloc;
use alloc::collections::BTreeSet;
use alloc::vec::Vec;

use kvnc_common::{Address, Amount, ContractError, ContractResult, Host};

pub type MultisigId = [u8; 32];
pub type TxId = u64;

#[derive(Clone, Debug)]
pub struct Multisig {
    pub owners: BTreeSet<Address>,
    pub threshold: u32,
    pub next_tx_id: TxId,
    /// tx_id → pending transaction
    // In real code use a map; here we sketch the structure
}

#[derive(Clone, Debug)]
pub struct PendingTx {
    pub id: TxId,
    pub to: Address,
    pub amount: Amount,
    pub data: Vec<u8>,          // optional call data
    pub confirmations: BTreeSet<Address>,
    pub executed: bool,
}

impl Multisig {
    /// Deploy a new multisig. Caller becomes first owner.
    pub fn create(
        host: &mut impl Host,
        owners: Vec<Address>,
        threshold: u32,
    ) -> ContractResult<MultisigId> {
        if owners.is_empty() || threshold == 0 || threshold as usize > owners.len() {
            return Err(ContractError::InvalidInput);
        }

        let mut set = BTreeSet::new();
        for o in owners {
            set.insert(o);
        }

        let ms = Multisig {
            owners: set,
            threshold,
            next_tx_id: 1,
        };

        let id = Self::compute_id(&ms);
        Self::store(host, &id, &ms)?;
        host.emit_event(b"multisig_created", &id);
        Ok(id)
    }

    /// Propose a transfer / call. Any owner can propose.
    pub fn propose(
        host: &mut impl Host,
        id: MultisigId,
        to: Address,
        amount: Amount,
        data: Vec<u8>,
    ) -> ContractResult<TxId> {
        let mut ms = Self::load(host, &id)?;
        let caller = host.caller();
        if !ms.owners.contains(&caller) {
            return Err(ContractError::Unauthorized);
        }

        let tx_id = ms.next_tx_id;
        ms.next_tx_id = ms.next_tx_id.saturating_add(1);

        let mut conf = BTreeSet::new();
        conf.insert(caller); // proposer auto-confirms

        let tx = PendingTx {
            id: tx_id,
            to,
            amount,
            data,
            confirmations: conf,
            executed: false,
        };

        Self::store_tx(host, &id, &tx)?;
        Self::store(host, &id, &ms)?;

        host.emit_event(b"multisig_proposed", &tx_id.to_le_bytes());
        Ok(tx_id)
    }

    /// Confirm a pending transaction.
    pub fn confirm(host: &mut impl Host, id: MultisigId, tx_id: TxId) -> ContractResult<()> {
        let ms = Self::load(host, &id)?;
        let caller = host.caller();
        if !ms.owners.contains(&caller) {
            return Err(ContractError::Unauthorized);
        }

        let mut tx = Self::load_tx(host, &id, tx_id)?;
        if tx.executed {
            return Err(ContractError::InvalidInput);
        }

        tx.confirmations.insert(caller);
        Self::store_tx(host, &id, &tx)?;

        host.emit_event(b"multisig_confirmed", &tx_id.to_le_bytes());
        Ok(())
    }

    /// Execute once threshold is reached.
    pub fn execute(host: &mut impl Host, id: MultisigId, tx_id: TxId) -> ContractResult<()> {
        let ms = Self::load(host, &id)?;
        let mut tx = Self::load_tx(host, &id, tx_id)?;

        if tx.executed {
            return Err(ContractError::InvalidInput);
        }
        if tx.confirmations.len() < ms.threshold as usize {
            return Err(ContractError::ThresholdNotMet);
        }

        // Funds come from the multisig contract itself
        host.transfer(&contract_self(), &tx.to, tx.amount)?;
        // Optional: if data is non-empty, host could forward a call

        tx.executed = true;
        Self::store_tx(host, &id, &tx)?;

        host.emit_event(b"multisig_executed", &tx_id.to_le_bytes());
        Ok(())
    }

    // Owner management can be added later as special txs that also require threshold.

    fn compute_id(_ms: &Multisig) -> MultisigId {
        [0u8; 32]
    }

    fn store(_host: &mut impl Host, _id: &MultisigId, _ms: &Multisig) -> ContractResult<()> {
        Ok(())
    }

    fn load(_host: &impl Host, _id: &MultisigId) -> ContractResult<Multisig> {
        Err(ContractError::NotFound)
    }

    fn store_tx(_host: &mut impl Host, _id: &MultisigId, _tx: &PendingTx) -> ContractResult<()> {
        Ok(())
    }

    fn load_tx(_host: &impl Host, _id: &MultisigId, _tx_id: TxId) -> ContractResult<PendingTx> {
        Err(ContractError::NotFound)
    }
}

fn contract_self() -> Address {
    [0u8; 32]
}

#[no_mangle]
pub extern "C" fn multisig_create() {}
#[no_mangle]
pub extern "C" fn multisig_propose() {}
#[no_mangle]
pub extern "C" fn multisig_confirm() {}
#[no_mangle]
pub extern "C" fn multisig_execute() {}

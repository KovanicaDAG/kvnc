//! Time-lock / Vesting Vault for kvnc
//!
//! Supports:
//!   - Absolute time-lock (unlock after timestamp)
//!   - Linear vesting (claimable portion grows over time)
//!   - Cliff + linear (optional)
//!   - Beneficiary + optional admin (for cancel / emergency)
//!
//! Matches the spirit of Protocol KVP-105 and the treasury vesting model.

#![cfg_attr(not(feature = "std"), no_std)]

extern crate alloc;
use alloc::vec::Vec;

use kvnc_common::{Address, Amount, ContractError, ContractResult, Height, Host, Timestamp};

pub type VaultId = [u8; 32];

#[derive(Clone, Debug)]
pub enum VestingSchedule {
    /// Unlock everything after `unlock_at`.
    Absolute { unlock_at: Timestamp },
    /// Linear from `start` to `end`. Nothing before start.
    Linear {
        start: Timestamp,
        end: Timestamp,
        /// Optional cliff: nothing claimable before cliff.
        cliff: Option<Timestamp>,
    },
}

#[derive(Clone, Debug)]
pub struct Vault {
    pub creator: Address,
    pub beneficiary: Address,
    pub total: Amount,
    pub claimed: Amount,
    pub schedule: VestingSchedule,
    pub cancelled: bool,
}

impl Vault {
    /// Create a vault. Funds are pulled from caller into the contract.
    pub fn create(
        host: &mut impl Host,
        beneficiary: Address,
        amount: Amount,
        schedule: VestingSchedule,
    ) -> ContractResult<VaultId> {
        if amount == 0 {
            return Err(ContractError::InvalidInput);
        }
        Self::validate_schedule(&schedule, host.timestamp())?;

        let creator = host.caller();
        host.transfer(&creator, &contract_self(), amount)?;

        let vault = Vault {
            creator,
            beneficiary,
            total: amount,
            claimed: 0,
            schedule,
            cancelled: false,
        };

        let id = Self::compute_id(&vault, host.block_height());
        Self::store(host, &id, &vault)?;

        host.emit_event(b"vault_created", &id);
        Ok(id)
    }

    /// Claim the currently vested (but not yet claimed) amount.
    pub fn claim(host: &mut impl Host, id: VaultId) -> ContractResult<Amount> {
        let mut vault = Self::load(host, &id)?;
        if vault.cancelled {
            return Err(ContractError::InvalidInput);
        }
        if host.caller() != vault.beneficiary {
            return Err(ContractError::Unauthorized);
        }

        let vested = vault.vested_amount(host.timestamp());
        let claimable = vested.saturating_sub(vault.claimed);
        if claimable == 0 {
            return Ok(0);
        }

        vault.claimed = vault.claimed.saturating_add(claimable);
        Self::store(host, &id, &vault)?;

        host.transfer(&contract_self(), &vault.beneficiary, claimable)?;
        host.emit_event(b"vault_claimed", &id);
        Ok(claimable)
    }

    /// Optional: creator can cancel and reclaim unvested (or all remaining) funds.
    /// Policy choice – here we allow reclaim of everything not yet claimed.
    pub fn cancel(host: &mut impl Host, id: VaultId) -> ContractResult<()> {
        let mut vault = Self::load(host, &id)?;
        if host.caller() != vault.creator {
            return Err(ContractError::Unauthorized);
        }
        if vault.cancelled {
            return Err(ContractError::InvalidInput);
        }

        let remaining = vault.total.saturating_sub(vault.claimed);
        vault.cancelled = true;
        Self::store(host, &id, &vault)?;

        if remaining > 0 {
            host.transfer(&contract_self(), &vault.creator, remaining)?;
        }
        host.emit_event(b"vault_cancelled", &id);
        Ok(())
    }

    /// How much is vested at the given timestamp.
    pub fn vested_amount(&self, now: Timestamp) -> Amount {
        match &self.schedule {
            VestingSchedule::Absolute { unlock_at } => {
                if now >= *unlock_at {
                    self.total
                } else {
                    0
                }
            }
            VestingSchedule::Linear { start, end, cliff } => {
                if let Some(c) = cliff {
                    if now < *c {
                        return 0;
                    }
                }
                if now < *start {
                    return 0;
                }
                if now >= *end {
                    return self.total;
                }
                let duration = end.saturating_sub(*start);
                if duration == 0 {
                    return self.total;
                }
                let elapsed = now.saturating_sub(*start);
                // simple linear: total * elapsed / duration
                // careful with overflow – use u128
                (self.total as u128)
                    .saturating_mul(elapsed as u128)
                    .saturating_div(duration as u128) as Amount
            }
        }
    }

    fn validate_schedule(schedule: &VestingSchedule, now: Timestamp) -> ContractResult<()> {
        match schedule {
            VestingSchedule::Absolute { unlock_at } => {
                if *unlock_at <= now {
                    return Err(ContractError::InvalidInput);
                }
            }
            VestingSchedule::Linear { start, end, cliff } => {
                if *end <= *start {
                    return Err(ContractError::InvalidInput);
                }
                if let Some(c) = cliff {
                    if *c > *end {
                        return Err(ContractError::InvalidInput);
                    }
                }
            }
        }
        Ok(())
    }

    fn compute_id(_vault: &Vault, height: Height) -> VaultId {
        let mut id = [0u8; 32];
        id[0..8].copy_from_slice(&height.to_le_bytes());
        id
    }

    fn store(_host: &mut impl Host, _id: &VaultId, _vault: &Vault) -> ContractResult<()> {
        Ok(())
    }

    fn load(_host: &impl Host, _id: &VaultId) -> ContractResult<Vault> {
        Err(ContractError::NotFound)
    }
}

fn contract_self() -> Address {
    [0u8; 32]
}

// Wasmi exports
#[no_mangle]
pub extern "C" fn vault_create() {}
#[no_mangle]
pub extern "C" fn vault_claim() {}
#[no_mangle]
pub extern "C" fn vault_cancel() {}

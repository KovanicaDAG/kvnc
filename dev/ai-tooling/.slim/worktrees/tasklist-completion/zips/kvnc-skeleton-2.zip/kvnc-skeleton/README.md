# kvnc Contract & Tokenomics Skeleton

Clean, independent skeletons for the features you asked for.  
**No code or types are imported from kovanica-protocol.**  
These are designed from scratch for the `kvnc` architecture:

- Mysticeti-style DAG
- Account model
- Wasmi (deterministic WASM)
- Host interface for balance / transfer / storage / events

## Layout

```
kvnc-skeleton/
├── common/
│   └── types.rs              # Address, Amount, Host trait, errors
├── contracts/
│   ├── htlc/lib.rs           # Hashed Time-Lock Contract
│   ├── vault/lib.rs          # Time-lock + linear vesting vault
│   ├── multisig/lib.rs       # M-of-N multisig wallet
│   └── token/lib.rs          # Standardized fungible token
├── staking/
│   └── tokenomics_align.rs   # Emission + treasury constants & pure functions
└── README.md
```

## 1. HTLC (`contracts/htlc`)

Classic atomic-swap primitive.

- `create(claimer, amount, hash_lock, expiry)`
- `claim(id, preimage)` – only before expiry, hash must match
- `refund(id)` – only after expiry

Funds are escrowed in the contract account.

## 2. Time-lock / Vesting Vault (`contracts/vault`)

- Absolute unlock
- Linear vesting (with optional cliff)
- `claim` by beneficiary
- Optional `cancel` by creator (reclaims remaining)

Matches the spirit of a treasury vesting schedule.

## 3. Multisig (`contracts/multisig`)

Simple M-of-N:

- `create(owners, threshold)`
- `propose(to, amount, data)`
- `confirm(tx_id)`
- `execute(tx_id)` once threshold reached

Owners stored in a BTreeSet for deterministic ordering.

## 4. Standardized Fungible Token (`contracts/token`)

Minimal ERC-20 style:

- `create(name, symbol, decimals, initial_supply)`
- `transfer` / `approve` / `transfer_from`
- `mint` (minter only) / `burn`
- pause flag

One contract instance = one token.  
Later you can promote a system-level multi-asset if needed.

## 5. Tokenomics Alignment (`staking/tokenomics_align.rs`)

Pure constants + functions that bring kvnc numbers in line with the well-known 90.2 M / 10 KVNC / 2 050 000 era / ×¾ decay schedule, while staying independent:

| Parameter              | Value                          |
|------------------------|--------------------------------|
| Total supply           | 90 200 000 KVNC                |
| Decimals               | 9                              |
| Founder premine        | 200 000 KVNC                   |
| Treasury               | 8 000 000 KVNC (linear 1 M/yr) |
| Initial reward         | 10 KVNC                        |
| Era length             | 2 050 000 committed leaders    |
| Decay                  | × 3/4 per era                  |
| Min validator stake    | 50 000 KVNC                    |
| Active validators      | 15–21                          |

Also includes:

- `block_reward(height)`
- `treasury_vested(height)`
- `StakingState::on_leader_committed`
- `treasury_claimable` / `claim_treasury`

## How to use

1. Copy the folders into your real `kvnc` workspace.
2. Implement the `Host` trait with your actual Wasmi host functions (balance, transfer, storage, hash, events).
3. Replace the placeholder `store` / `load` / `host_hash` / `contract_self` with real persistence.
4. Wire the staking constants into `kvnc-staking` and call `on_leader_committed` from the execution layer on every committed leader.
5. Export the `#[no_mangle]` entry points (or use a proper ABI dispatcher) so the runtime can call them.

## Design principles used

- `no_std` friendly
- Deterministic (BTreeMap / BTreeSet)
- Explicit errors
- Events for indexers
- Minimal surface area – easy to audit and extend
- Zero dependency on the other project

This should give you a clean starting point without inheriting any mess from the older codebase.

//! Standardized Fungible Token (multi-asset) for kvnc
//!
//! Simple, minimal ERC-20-like interface adapted to account model + Wasmi.
//! Features:
//!   - mint (only minter / owner)
//!   - burn
//!   - transfer
//!   - approve / transfer_from
//!   - total_supply, balance_of, allowance
//!
//! One contract instance = one token.
//! For true multi-asset native support you can later promote this to a system precompile.

#![cfg_attr(not(feature = "std"), no_std)]

extern crate alloc;
use alloc::collections::BTreeMap;
use alloc::string::String;
use alloc::vec::Vec;

use kvnc_common::{Address, Amount, ContractError, ContractResult, Host};

#[derive(Clone, Debug)]
pub struct Token {
    pub name: String,
    pub symbol: String,
    pub decimals: u8,
    pub total_supply: Amount,
    pub owner: Address,          // can mint / change minter
    pub minter: Address,         // can mint
    pub balances: BTreeMap<Address, Amount>,
    pub allowances: BTreeMap<(Address, Address), Amount>, // owner → spender → amount
    pub paused: bool,
}

impl Token {
    /// Deploy a new token. Caller becomes owner + minter.
    pub fn create(
        host: &mut impl Host,
        name: String,
        symbol: String,
        decimals: u8,
        initial_supply: Amount,
    ) -> ContractResult<()> {
        if decimals > 18 {
            return Err(ContractError::InvalidInput);
        }

        let caller = host.caller();
        let mut balances = BTreeMap::new();
        if initial_supply > 0 {
            balances.insert(caller, initial_supply);
        }

        let token = Token {
            name,
            symbol,
            decimals,
            total_supply: initial_supply,
            owner: caller,
            minter: caller,
            balances,
            allowances: BTreeMap::new(),
            paused: false,
        };

        Self::store(host, &token)?;
        host.emit_event(b"token_created", &[]);
        Ok(())
    }

    pub fn transfer(host: &mut impl Host, to: Address, amount: Amount) -> ContractResult<()> {
        let mut token = Self::load(host)?;
        if token.paused {
            return Err(ContractError::Paused);
        }
        let from = host.caller();
        Self::move_balance(&mut token, &from, &to, amount)?;
        Self::store(host, &token)?;
        host.emit_event(b"transfer", &[]);
        Ok(())
    }

    pub fn approve(host: &mut impl Host, spender: Address, amount: Amount) -> ContractResult<()> {
        let mut token = Self::load(host)?;
        let owner = host.caller();
        token.allowances.insert((owner, spender), amount);
        Self::store(host, &token)?;
        host.emit_event(b"approval", &[]);
        Ok(())
    }

    pub fn transfer_from(
        host: &mut impl Host,
        from: Address,
        to: Address,
        amount: Amount,
    ) -> ContractResult<()> {
        let mut token = Self::load(host)?;
        if token.paused {
            return Err(ContractError::Paused);
        }
        let spender = host.caller();

        let key = (from, spender);
        let allowance = token.allowances.get(&key).copied().unwrap_or(0);
        if allowance < amount {
            return Err(ContractError::InsufficientBalance);
        }
        token.allowances.insert(key, allowance - amount);

        Self::move_balance(&mut token, &from, &to, amount)?;
        Self::store(host, &token)?;
        host.emit_event(b"transfer", &[]);
        Ok(())
    }

    pub fn mint(host: &mut impl Host, to: Address, amount: Amount) -> ContractResult<()> {
        let mut token = Self::load(host)?;
        if host.caller() != token.minter {
            return Err(ContractError::Unauthorized);
        }
        if token.paused {
            return Err(ContractError::Paused);
        }

        let new_supply = token
            .total_supply
            .checked_add(amount)
            .ok_or(ContractError::Overflow)?;
        token.total_supply = new_supply;

        let bal = token.balances.entry(to).or_insert(0);
        *bal = bal.checked_add(amount).ok_or(ContractError::Overflow)?;

        Self::store(host, &token)?;
        host.emit_event(b"mint", &[]);
        Ok(())
    }

    pub fn burn(host: &mut impl Host, amount: Amount) -> ContractResult<()> {
        let mut token = Self::load(host)?;
        let from = host.caller();
        let bal = token.balances.get(&from).copied().unwrap_or(0);
        if bal < amount {
            return Err(ContractError::InsufficientBalance);
        }
        token.balances.insert(from, bal - amount);
        token.total_supply = token.total_supply.saturating_sub(amount);
        Self::store(host, &token)?;
        host.emit_event(b"burn", &[]);
        Ok(())
    }

    // ---------- helpers ----------

    fn move_balance(
        token: &mut Token,
        from: &Address,
        to: &Address,
        amount: Amount,
    ) -> ContractResult<()> {
        let from_bal = token.balances.get(from).copied().unwrap_or(0);
        if from_bal < amount {
            return Err(ContractError::InsufficientBalance);
        }
        token.balances.insert(*from, from_bal - amount);
        let to_bal = token.balances.entry(*to).or_insert(0);
        *to_bal = to_bal.checked_add(amount).ok_or(ContractError::Overflow)?;
        Ok(())
    }

    fn store(_host: &mut impl Host, _token: &Token) -> ContractResult<()> {
        // serialize whole state or use host storage keys
        Ok(())
    }

    fn load(_host: &impl Host) -> ContractResult<Token> {
        Err(ContractError::NotFound)
    }
}

#[no_mangle]
pub extern "C" fn token_create() {}
#[no_mangle]
pub extern "C" fn token_transfer() {}
#[no_mangle]
pub extern "C" fn token_approve() {}
#[no_mangle]
pub extern "C" fn token_transfer_from() {}
#[no_mangle]
pub extern "C" fn token_mint() {}
#[no_mangle]
pub extern "C" fn token_burn() {}

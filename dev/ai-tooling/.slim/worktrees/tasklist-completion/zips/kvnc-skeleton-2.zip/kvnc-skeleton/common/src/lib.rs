//! Shared types for kvnc contracts.
//! Designed for Wasmi (deterministic WASM) + account-model host.
//! Keep this crate `no_std` friendly.

#![cfg_attr(not(feature = "std"), no_std)]

use core::fmt;

/// 32-byte address (account or contract).
pub type Address = [u8; 32];

/// 32-byte hash (SHA-256 / Blake3 / whatever host uses).
pub type Hash = [u8; 32];

/// Native token amount (base units). kvnc uses 9 decimals.
pub type Amount = u128;

/// Block / round height.
pub type Height = u64;

/// Timestamp in seconds (host-provided).
pub type Timestamp = u64;

/// Simple result type used across contracts.
pub type ContractResult<T> = Result<T, ContractError>;

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ContractError {
    Unauthorized,
    InsufficientBalance,
    InvalidInput,
    AlreadyExists,
    NotFound,
    Expired,
    NotExpired,
    HashMismatch,
    ThresholdNotMet,
    Paused,
    Overflow,
    Custom(u32),
}

impl fmt::Display for ContractError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Unauthorized => write!(f, "unauthorized"),
            Self::InsufficientBalance => write!(f, "insufficient balance"),
            Self::InvalidInput => write!(f, "invalid input"),
            Self::AlreadyExists => write!(f, "already exists"),
            Self::NotFound => write!(f, "not found"),
            Self::Expired => write!(f, "expired"),
            Self::NotExpired => write!(f, "not yet expired"),
            Self::HashMismatch => write!(f, "hash mismatch"),
            Self::ThresholdNotMet => write!(f, "threshold not met"),
            Self::Paused => write!(f, "contract paused"),
            Self::Overflow => write!(f, "arithmetic overflow"),
            Self::Custom(c) => write!(f, "custom error {}", c),
        }
    }
}

/// Minimal host interface expected by contracts.
/// In real kvnc this is provided by the Wasmi runtime / host functions.
pub trait Host {
    fn caller(&self) -> Address;
    fn block_height(&self) -> Height;
    fn timestamp(&self) -> Timestamp;
    fn balance_of(&self, addr: &Address) -> Amount;
    fn transfer(&mut self, from: &Address, to: &Address, amount: Amount) -> ContractResult<()>;
    fn emit_event(&mut self, topic: &[u8], data: &[u8]);
    // Optional: storage get/set if contracts use host storage instead of pure WASM memory
    fn storage_get(&self, key: &[u8]) -> Option<Vec<u8>>;
    fn storage_set(&mut self, key: &[u8], value: &[u8]);
}

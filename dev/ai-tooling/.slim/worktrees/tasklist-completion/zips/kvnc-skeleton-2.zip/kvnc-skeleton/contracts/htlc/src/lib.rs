//! HTLC (Hashed Time-Lock Contract) for kvnc
//!
//! Atomic swap primitive.
//! Paths:
//!   - claim  : reveal preimage before expiry → funds go to claimer
//!   - refund : after expiry → funds return to sender
//!
//! Designed for Wasmi. No external crates beyond core + common types.

#![cfg_attr(not(feature = "std"), no_std)]

extern crate alloc;
use alloc::vec::Vec;

use kvnc_common::{Address, Amount, ContractError, ContractResult, Hash, Height, Host, Timestamp};

/// Unique swap identifier (hash of the parameters or explicit id).
pub type SwapId = Hash;

#[derive(Clone, Debug)]
pub struct Htlc {
    pub sender: Address,
    pub claimer: Address,
    pub amount: Amount,
    pub hash_lock: Hash,       // SHA-256(preimage) or host hash
    pub expiry: Timestamp,     // absolute timestamp
    pub claimed: bool,
    pub refunded: bool,
}

impl Htlc {
    /// Create a new HTLC. Caller must be `sender` and must transfer `amount`.
    pub fn create(
        host: &mut impl Host,
        claimer: Address,
        amount: Amount,
        hash_lock: Hash,
        expiry: Timestamp,
    ) -> ContractResult<SwapId> {
        if amount == 0 {
            return Err(ContractError::InvalidInput);
        }
        if expiry <= host.timestamp() {
            return Err(ContractError::InvalidInput);
        }

        let sender = host.caller();
        // Pull funds from sender into the contract account (host handles escrow)
        host.transfer(&sender, &host.caller() /* contract self */, amount)?;

        let swap = Htlc {
            sender,
            claimer,
            amount,
            hash_lock,
            expiry,
            claimed: false,
            refunded: false,
        };

        let id = Self::compute_id(&swap);
        // Persist under id (host storage or contract-owned map)
        Self::store(host, &id, &swap)?;

        host.emit_event(b"htlc_created", &id);
        Ok(id)
    }

    /// Claim with preimage before expiry.
    pub fn claim(host: &mut impl Host, id: SwapId, preimage: &[u8]) -> ContractResult<()> {
        let mut swap = Self::load(host, &id)?;
        if swap.claimed || swap.refunded {
            return Err(ContractError::InvalidInput);
        }
        if host.timestamp() >= swap.expiry {
            return Err(ContractError::Expired);
        }

        let computed = host_hash(preimage); // host provides hash function
        if computed != swap.hash_lock {
            return Err(ContractError::HashMismatch);
        }

        // Only claimer can claim (or anyone who knows preimage – classic HTLC allows anyone)
        // Here we restrict to the designated claimer for safety.
        if host.caller() != swap.claimer {
            return Err(ContractError::Unauthorized);
        }

        swap.claimed = true;
        Self::store(host, &id, &swap)?;

        // Release funds to claimer
        host.transfer(&contract_self(), &swap.claimer, swap.amount)?;

        host.emit_event(b"htlc_claimed", &id);
        Ok(())
    }

    /// Refund after expiry.
    pub fn refund(host: &mut impl Host, id: SwapId) -> ContractResult<()> {
        let mut swap = Self::load(host, &id)?;
        if swap.claimed || swap.refunded {
            return Err(ContractError::InvalidInput);
        }
        if host.timestamp() < swap.expiry {
            return Err(ContractError::NotExpired);
        }

        // Anyone can trigger refund after expiry (sender gets funds back)
        swap.refunded = true;
        Self::store(host, &id, &swap)?;

        host.transfer(&contract_self(), &swap.sender, swap.amount)?;

        host.emit_event(b"htlc_refunded", &id);
        Ok(())
    }

    // ---------- internal helpers (to be implemented with real storage) ----------

    fn compute_id(swap: &Htlc) -> SwapId {
        // Deterministic: hash(sender || claimer || amount || hash_lock || expiry)
        // Placeholder – replace with real host hash
        let mut buf = [0u8; 32];
        buf[0..8].copy_from_slice(&swap.amount.to_le_bytes()[..8]);
        buf
    }

    fn store(_host: &mut impl Host, _id: &SwapId, _swap: &Htlc) -> ContractResult<()> {
        // TODO: serialize + host.storage_set
        Ok(())
    }

    fn load(_host: &impl Host, _id: &SwapId) -> ContractResult<Htlc> {
        // TODO: host.storage_get + deserialize
        Err(ContractError::NotFound)
    }
}

/// Placeholder for the contract's own address (host provides it).
fn contract_self() -> Address {
    [0u8; 32]
}

/// Host must expose a deterministic hash.
fn host_hash(_data: &[u8]) -> Hash {
    [0u8; 32] // replace with real call
}

// ---------- entry points for Wasmi export ----------
// Real runtime will call these via a dispatcher.

#[no_mangle]
pub extern "C" fn htlc_create(/* encoded args */) { /* dispatch */ }

#[no_mangle]
pub extern "C" fn htlc_claim(/* encoded args */) { /* dispatch */ }

#[no_mangle]
pub extern "C" fn htlc_refund(/* encoded args */) { /* dispatch */ }

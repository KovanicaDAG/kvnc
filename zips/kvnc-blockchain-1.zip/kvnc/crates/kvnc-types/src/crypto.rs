//! Cryptographic primitives re-exports and wrappers.

use ed25519_dalek::{Signature as DalekSignature, VerifyingKey};
use serde::{Deserialize, Serialize};

/// Ed25519 public key wrapper.
#[derive(Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct PublicKey(pub [u8; 32]);

impl PublicKey {
    pub fn as_bytes(&self) -> &[u8; 32] {
        &self.0
    }

    pub fn from_bytes(bytes: [u8; 32]) -> Self {
        Self(bytes)
    }
}

/// Ed25519 signature wrapper.
#[derive(Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct Signature(pub [u8; 64]);

impl Signature {
    pub fn as_bytes(&self) -> &[u8; 64] {
        &self.0
    }
}

// Convenience conversions
impl From<VerifyingKey> for PublicKey {
    fn from(vk: VerifyingKey) -> Self {
        Self(vk.to_bytes())
    }
}

impl From<DalekSignature> for Signature {
    fn from(sig: DalekSignature) -> Self {
        Self(sig.to_bytes())
    }
}

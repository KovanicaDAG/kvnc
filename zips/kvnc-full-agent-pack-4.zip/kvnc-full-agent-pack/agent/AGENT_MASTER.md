# KVNC Full Agent Pack — Master Instructions

**Repo:** https://github.com/KovanicaDAG/kvnc  
**Pack date:** 2026-10-07  
**Snapshot:** full crates + docs + historical next-steps (no nested zips)

---

## 1. What this pack contains

```
kvnc-full-agent-pack/
├── README.md                          ← start here (human)
├── agent/
│   ├── AGENT_MASTER.md                ← this file (agent)
│   └── PHASE13_INSTRUCTIONS.md        ← detailed Phase 13 work order
├── repo-snapshot/                     ← current source tree
│   ├── Cargo.toml
│   ├── README.md
│   ├── tasklist.md
│   ├── config.example.toml
│   ├── crates/                        ← ALL crates
│   ├── docs/
│   └── kvnc-next-steps/               ← earlier agent prompts (historical)
```

Work on the **live git repo**. This snapshot is the baseline + reference. Prefer live files if they have diverged; re-apply the intent of these instructions.

---

## 2. Project identity (do not confuse)

| Project | Consensus | Ledger | Contracts | Decimals |
|---------|-----------|--------|-----------|----------|
| **kvnc** (this repo) | Mysticeti-style DAG | Account + staking | Wasmi WASM | 9 |
| kovanica-protocol | GHOSTDAG k=3 | Pure UTXO | Script / KVP | 8 |

- Do **not** mix architectures.
- Tokenomics numbers are shared in spirit (90.2M, 10 KVNC, 2.05M era, ×¾) but implementations differ.
- Never port Mysticeti/Wasmi/account code into kovanica-protocol.

---

## 3. Locked decisions (do not change)

- Total supply 90_200_000 KVNC, 9 decimals  
- Initial reward 10 KVNC, era 2_050_000 committed leaders, decay × 3/4  
- Treasury 8M linear over 8 years  
- Reward minted **only** on committed leader via `on_leader_committed`  
- Target 15–21 validators, min stake 50_000 KVNC  
- Resource target: 2–4 GB RAM full node  
- `#![deny(unsafe_code)]` where present  

---

## 4. Current maturity (2026-10-07)

**Done / strong:**
- Tokenomics + staking emission + treasury vesting + live reward path  
- Consensus commit rules (direct + indirect), linearizer, ~74 tests + proptest  
- Storage (redb): block / state / consensus stores  
- Network base: libp2p gossipsub, kad, ping, basic ban  
- Wasmi runtime + Host surface + HTLC/Vault/Multisig/Token  
- Node binary, RPC (HTTP), CLI contract commands  

**Weak / next (Phase 13 focus):**
- Block **sync protocol** (request/response ranges)  
- Peer scoring beyond ping failures  
- Leader **timeout / skip**  
- Strict DAG block validation (parents, signature, round)  
- Node event wiring for gap → sync  
- Receipts + state root (after networking stable)  
- Multi-node integration tests  

---

## 5. Phase 13 work order (strict priority)

### P0 — Networking & Sync
Primary files:
- `crates/kvnc-network/src/sync.rs`
- `crates/kvnc-network/src/service.rs`
- `crates/kvnc-network/src/behaviour.rs`
- `crates/kvnc-network/src/lib.rs`
- `crates/kvnc-network/src/topics.rs`

Goals:
1. `SyncResponse` (blocks or hashes) with size limits  
2. Serve range from `DagStore` on valid `SyncRequest`  
3. Detect gossip gaps → request missing rounds  
4. Peer score: invalid payload, oversized range, spam → ban  
5. Reconnect / target peer count basics  

Exit: Node A pulls missing rounds from Node B; invalid peer gets banned.

### P1 — Consensus hardening
Primary files:
- `crates/kvnc-consensus/src/engine.rs`
- `crates/kvnc-consensus/src/committer.rs`
- `crates/kvnc-consensus/src/linearizer.rs`
- `crates/kvnc-consensus/src/types.rs`
- `crates/kvnc-consensus/tests/*`

Goals:
1. Leader timeout → Skip status, continue rounds  
2. Do not generate ephemeral keypair inside engine start (use node keystore)  
3. Harden late / conflicting leader edge cases  
4. Tests: slow leader, timeout skip, safety still holds  

### P2 — DAG validation
Primary files:
- `crates/kvnc-dag/src/block_manager.rs`
- `crates/kvnc-dag/src/dag_store.rs`

Goals:
1. `process_block`: signature, round continuity, parents exist, parent.round == round-1  
2. Prefer 2f+1 / high-quality parents in `find_parents`  
3. Reject orphans early  

### P3 — Node wiring
Primary files:
- `crates/kvnc-node/src/main.rs`
- `crates/kvnc-node/src/config.rs`

Goals:
1. NetworkEvent → consensus + dag ingestion  
2. Config knobs: sync batch, peer target, timeout multiplier, ban threshold, max sync range  
3. Drive sync when height/round gap detected  

### P4 — State completeness (only after P0–P2 green)
- `crates/kvnc-execution/src/lib.rs` — receipts  
- `crates/kvnc-storage/src/state_store.rs` — persist receipts / state root  
- Pruning actively used from node  

---

## 6. Hard rules for any agent

1. **Do not** change tokenomics constants or reward formula.  
2. **Do not** add new contract types or break Host ABI in this phase.  
3. **Do not** rewrite the whole networking stack — extend existing libp2p service.  
4. Small commits; every non-trivial change needs tests.  
5. After edits always run:
   ```bash
   cargo fmt
   cargo clippy -p kvnc-network -p kvnc-consensus -p kvnc-dag -p kvnc-node -- -D warnings
   cargo test -p kvnc-network -p kvnc-consensus -p kvnc-dag --all-targets
   ```
6. Stay within 2–4 GB RAM assumptions — no unbounded caches.  
7. Document wire formats (bincode fields) in module docs.  

---

## 7. Suggested first commits

1. `sync.rs`: `SyncResponse` + encode/decode + max range  
2. `service.rs`: serve blocks for valid range from DagStore  
3. `service.rs`: gap detection → outbound SyncRequest  
4. `engine.rs`: leader timeout → Skip  
5. `block_manager.rs`: full validation before put  
6. `main.rs` + `config.rs`: wire events and config  

---

## 8. Out of scope for this phase

- New contracts / Host methods  
- WebSocket RPC subscriptions  
- Delegation, slashing, governance  
- Full Merkle Patricia Trie  
- Public testnet marketing / explorer UI  
- Merging with kovanica-protocol  

---

## 9. Success criteria (Phase 13 done)

- [ ] Block range sync works between ≥2 nodes  
- [ ] Leader timeout/skip works and is tested  
- [ ] Invalid blocks/peers rejected and scored  
- [ ] Existing consensus tests still green (incl. proptest)  
- [ ] Clear path to 5–7 node local cluster + partition recovery  
- [ ] Config exposes sync/timeout/ban parameters  

---

## 10. References inside pack

| Path | Use |
|------|-----|
| `repo-snapshot/tasklist.md` | Full project checklist (many Phase 0–12 items already done) |
| `repo-snapshot/docs/ARCHITECTURE.md` | Component flow |
| `repo-snapshot/docs/TOKENOMICS.md` | Locked economics |
| `repo-snapshot/docs/CONTRACTS.md` | Existing contract surface (do not expand) |
| `agent/PHASE13_INSTRUCTIONS.md` | Shorter Phase-13-only checklist |
| `repo-snapshot/kvnc-next-steps/` | Historical agent prompts (already integrated; reference only) |

Start with **P0 network sync**. Everything else depends on nodes being able to exchange missing blocks.

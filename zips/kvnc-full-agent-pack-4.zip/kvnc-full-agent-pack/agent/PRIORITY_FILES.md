# Priority file index (Phase 13)

## P0 Network
- repo-snapshot/crates/kvnc-network/src/sync.rs
- repo-snapshot/crates/kvnc-network/src/service.rs
- repo-snapshot/crates/kvnc-network/src/behaviour.rs
- repo-snapshot/crates/kvnc-network/src/lib.rs
- repo-snapshot/crates/kvnc-network/src/topics.rs
- repo-snapshot/crates/kvnc-network/src/error.rs
- repo-snapshot/crates/kvnc-network/Cargo.toml

## P1 Consensus
- repo-snapshot/crates/kvnc-consensus/src/engine.rs
- repo-snapshot/crates/kvnc-consensus/src/committer.rs
- repo-snapshot/crates/kvnc-consensus/src/linearizer.rs
- repo-snapshot/crates/kvnc-consensus/src/types.rs
- repo-snapshot/crates/kvnc-consensus/src/lib.rs
- repo-snapshot/crates/kvnc-consensus/tests/committer.rs
- repo-snapshot/crates/kvnc-consensus/tests/engine.rs
- repo-snapshot/crates/kvnc-consensus/tests/linearizer.rs
- repo-snapshot/crates/kvnc-consensus/tests/properties.rs
- repo-snapshot/crates/kvnc-consensus/tests/wave_arithmetic.rs
- repo-snapshot/crates/kvnc-consensus/tests/common/mod.rs

## P2 DAG
- repo-snapshot/crates/kvnc-dag/src/block_manager.rs
- repo-snapshot/crates/kvnc-dag/src/dag_store.rs
- repo-snapshot/crates/kvnc-dag/src/lib.rs

## P3 Node
- repo-snapshot/crates/kvnc-node/src/main.rs
- repo-snapshot/crates/kvnc-node/src/config.rs

## P4 later
- repo-snapshot/crates/kvnc-execution/src/lib.rs
- repo-snapshot/crates/kvnc-storage/src/state_store.rs
- repo-snapshot/crates/kvnc-storage/src/consensus_store.rs

## Supporting (read-only this phase)
- repo-snapshot/crates/kvnc-types/**
- repo-snapshot/crates/kvnc-staking/**   # DO NOT change emission math
- repo-snapshot/docs/ARCHITECTURE.md
- repo-snapshot/docs/TOKENOMICS.md
- repo-snapshot/tasklist.md

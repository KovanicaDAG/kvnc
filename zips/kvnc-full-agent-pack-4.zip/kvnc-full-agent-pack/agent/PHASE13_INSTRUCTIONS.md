# Phase 13 — Networking + Consensus Hardening (checklist)

See `AGENT_MASTER.md` for full context. This file is the executable work order.

## P0 — Network sync (do first)

| File | Action |
|------|--------|
| `crates/kvnc-network/src/sync.rs` | Add `SyncResponse { blocks: Vec<StatementBlock> }` (or hash list + separate fetch). Encode/decode. Cap max rounds per request (e.g. 64–256). |
| `crates/kvnc-network/src/service.rs` | On SYNC message: if valid request, load blocks from `DagStore` for `[from,to]`, reply. On gap after gossip: send `SyncRequest`. Track peer scores; ban on invalid/oversized. |
| `crates/kvnc-network/src/behaviour.rs` | Prefer request-response for large ranges if gossip is insufficient; otherwise keep gossip + explicit response topic. |
| `crates/kvnc-network/src/lib.rs` | Extend `NetworkEvent` (SyncCompleted, PeerScored, Ban). |
| `crates/kvnc-network/src/topics.rs` | Keep topics consistent; document wire format. |

**Tests:** encode/decode, invalid range rejected, serve empty/missing rounds safely.

## P1 — Consensus timeout

| File | Action |
|------|--------|
| `crates/kvnc-consensus/src/engine.rs` | Track time since leader expected; after timeout mark Skip and advance. Stop generating keypair in `start()` — inject from node. |
| `crates/kvnc-consensus/src/committer.rs` | Accept Skip status in commit path; no stuck Undecided forever. |
| `crates/kvnc-consensus/src/types.rs` | Ensure LeaderStatus has Skip (or equivalent). |
| `crates/kvnc-consensus/tests/` | Add slow-leader / timeout scenarios; keep proptest safety green. |

## P2 — DAG validation

| File | Action |
|------|--------|
| `crates/kvnc-dag/src/block_manager.rs` | Validate signature, round, parents exist, parent.round == round-1 before accept. |
| `crates/kvnc-dag/src/dag_store.rs` | `find_parents`: prefer available previous-round blocks; document 2f+1 intent. |

## P3 — Node wiring

| File | Action |
|------|--------|
| `crates/kvnc-node/src/config.rs` | `sync_batch_size`, `max_sync_range`, `peer_target`, `round_timeout_multiplier`, `ban_threshold`. |
| `crates/kvnc-node/src/main.rs` | Connect NetworkEvent → process_block / sync; use config timeouts. |

## P4 — Later (receipts / state root)

Only after P0–P2 pass tests:
- `kvnc-execution/src/lib.rs` — receipts
- `kvnc-storage/src/state_store.rs` — persist

## Commands

```bash
cargo fmt
cargo clippy -p kvnc-network -p kvnc-consensus -p kvnc-dag -p kvnc-node -- -D warnings
cargo test -p kvnc-network -p kvnc-consensus -p kvnc-dag --all-targets
```

## Do not

- Touch tokenomics / `kvnc-staking` emission math
- Add contracts
- Rewrite libp2p from scratch
- Merge with kovanica-protocol

## Done when

- Range sync works node-to-node
- Leader timeout → Skip tested
- Bad peers banned
- Existing consensus tests green

# KVNC Full Agent Pack (Phase 13)

**Date:** 2026-10-07  
**Source:** https://github.com/KovanicaDAG/kvnc

Comprehensive snapshot for agents implementing **multi-node stability**:
block sync, peer scoring, leader timeout, DAG validation, node wiring.

## Layout

```
kvnc-full-agent-pack/
├── README.md
├── agent/
│   ├── AGENT_MASTER.md           ← full context, rules, priorities
│   └── PHASE13_INSTRUCTIONS.md   ← short executable checklist
└── repo-snapshot/                ← full crates + docs + tasklist
    ├── Cargo.toml
    ├── README.md
    ├── tasklist.md
    ├── config.example.toml
    ├── crates/                   ← all 18 crates
    ├── docs/
    └── kvnc-next-steps/          ← historical prompts (reference only)
```

## How to use

1. Read `agent/AGENT_MASTER.md`.
2. Follow `agent/PHASE13_INSTRUCTIONS.md` in order (P0 → P1 → P2 → P3).
3. Implement against the **live** git repo; use `repo-snapshot/` as baseline.
4. Do **not** change tokenomics or add contracts in this phase.
5. Keep tests green:

```bash
cargo test -p kvnc-network -p kvnc-consensus -p kvnc-dag --all-targets
```

## Success

- Nodes can sync missing block ranges
- Leader timeout / skip works
- Invalid peers are banned
- Consensus property tests still pass
- Path to 5–7 node local cluster is clear

## Not included (on purpose)

- Nested historical zips
- Large brand-assets duplicates
- `.git` history (clone live repo for that)

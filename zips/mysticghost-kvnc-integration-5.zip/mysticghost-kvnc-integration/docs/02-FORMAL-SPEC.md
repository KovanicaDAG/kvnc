# MysticGhost – Formal Specification (kvnc version)

**Version:** 0.1.0-draft  
**Date:** 2026-10-07

---

## 1. System Model

- Partially synchronous network (GST + Δ).
- n validators, f < n/3 Byzantine.
- Stake vector known and fixed for an epoch (or slowly changing).
- Existing kvnc primitives: Ed25519, BLAKE3, stake-weighted VRF, libp2p.

## 2. Block & Wave Definitions

Identical to current kvnc:

- `wave ∈ ℕ`
- `round ∈ {0,1,2}`
- LeaderBlock only in round 0 by the scheduled leader
- OrdinaryBlocks in round 1
- Votes in round 1 / 2

## 3. Commit Rules

Unchanged from current `UniversalCommitter`:

- **Direct commit**: Leader receives ≥ 2f+1 votes in its wave.
- **Indirect commit**: A later directly-committed leader has the earlier leader in its causal history (or blue-set after colouring).

## 4. Scoped GHOSTDAG (new)

### 4.1 Mergeset

```
mergeset(L) = { B | B is reachable from L ∧ B ∉ any previous CommittedSubDag }
```

### 4.2 Colouring

Run classic GHOSTDAG with parameter k = 3 on the induced subgraph of:

```
mergeset(L) ∪ previous_committed_tips
```

Definitions (standard):

- Blue anticone of B = set of blue blocks that are incomparable to B.
- B is coloured blue if the largest blue anticone has size ≤ k.
- Selected parent of B = blue parent with highest blue-score (tie-break by hash).

### 4.3 Output

```
CommittedSubDag {
    leader: L,
    blocks: topological_order(blue_set),  // via selected-parent
    blue_score: ...,
    ...
}
```

This `CommittedSubDag` is handed to the existing execution layer exactly as today.

## 5. Invariants

1. The blue-set of any mergeset is conflict-free (GHOSTDAG k-cluster property).
2. Honest validators never vote for two conflicting leaders of the same wave.
3. Once a wave is fully committed and older than the pruning window, its non-blue blocks may be discarded.

## 6. Safety Sketch

Suppose two conflicting blocks B and B' both appear in some CommittedSubDag.  
They must belong to the same mergeset (or a later mergeset that includes the earlier tips).  
GHOSTDAG k=3 guarantees that a mergeset’s blue-set contains no conflicts. Contradiction.

## 7. Liveness Sketch

After GST, an honest leader can disseminate its block and collect 2f+1 votes within a constant number of rounds → direct commit.  
Byzantine or offline leaders are skipped; later honest leaders indirectly commit them via the DAG + colouring.

## 8. Complexity

- Colouring cost is proportional to mergeset size (expected small).
- Memory: only the current wave + a bounded window of recent waves need to stay in RAM.

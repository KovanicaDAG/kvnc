# 04 – Resource Budget (hard constraints for kvnc)

These limits are **normative** for the MysticGhost integration on kvnc.  
Any design that systematically violates them must be rejected or made optional.

## Target

| Metric                    | Soft limit      | Hard limit      |
|---------------------------|-----------------|-----------------|
| Full node RSS (idle)      | < 1.5 GB        | < 2.0 GB        |
| Full node RSS (moderate load, 21 vals) | < 2.5 GB | < 3.0 GB        |
| Full node RSS (peak)      | < 3.5 GB        | < 4.0 GB        |
| Mergeset size (typical)   | < 300 blocks    | < 1 000 blocks  |
| Waves kept in RAM         | ≤ 120           | ≤ 200           |

## Design rules that protect the budget

1. **Scoped colouring only**  
   Never run GHOSTDAG on the entire history. Only on the mergeset of the newly committed leader.

2. **Aggressive pruning**  
   - Non-blue blocks of a committed wave may be deleted immediately (or after a short grace period).  
   - Waves older than `PRUNE_WINDOW` (default 100) are removed from the in-memory DAG store.

3. **No unbounded indexes**  
   Any new index (reachability, blue-score cache, etc.) must have a bounded size or be rebuildable from the pruned store.

4. **Feature flag**  
   Pure Mysticeti mode (no GHOSTDAG) must remain available so operators can fall back if memory pressure appears.

5. **Measurement gate**  
   Every PR that touches consensus or the DAG store must include a short note on observed RSS on a 2 GB and a 4 GB test instance.

## Suggested configuration defaults

```toml
[consensus]
use_mysticghost = true
ghostdag_k = 3
prune_window_waves = 100
max_mergeset_blocks = 2000          # safety cap – panic or skip colouring if exceeded
```

## Monitoring

Expose at least:

- `mysticghost_mergeset_size`
- `mysticghost_colouring_duration_ms`
- `dag_blocks_in_memory`
- `process_resident_memory_bytes`

Alert when `dag_blocks_in_memory` or RSS approaches the hard limits.

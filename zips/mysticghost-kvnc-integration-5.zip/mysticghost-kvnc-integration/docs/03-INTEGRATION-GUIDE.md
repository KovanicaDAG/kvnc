# 03 – Integration Guide (step-by-step)

This guide assumes you already have a working (or almost working) kvnc tree where the consensus engine can produce `CommittedSubDag` values.

## Phase 0 – Prerequisites (do first)

1. Make sure the current production loop works:
   - Votes actually enter the engine
   - `CommittedSubDag` reaches `ExecutionContext::execute_committed_subdag`
   - Rewards are credited
2. All existing `kvnc-consensus` tests are green.
3. You can run a single node and observe commits.

Only after Phase 0 is solid should you start the hybrid.

## Phase 1 – Add the new modules (no behaviour change yet)

1. Copy the stub files from this package:

```bash
# from the root of your kvnc repo
cp -r /path/to/mysticghost-kvnc-integration/crates/kvnc-consensus/src/*.rs crates/kvnc-consensus/src/
cp -r /path/to/mysticghost-kvnc-integration/crates/kvnc-dag/src/*.rs crates/kvnc-dag/src/
```

2. Add the modules to the respective `lib.rs` / `mod.rs`:

```rust
// crates/kvnc-consensus/src/lib.rs
pub mod mysticghost;
pub mod ghostdag_scoped;
pub mod committer_mysticghost;
```

3. Make sure the crate still compiles (`cargo check -p kvnc-consensus`).

## Phase 2 – Implement mergeset extraction

In `kvnc-dag` (or wherever your block store lives) implement:

```rust
fn mergeset(&self, leader: &BlockHash) -> Vec<BlockHash>
```

Start with a simple recursive / BFS version. Later optimise with the reachability index you already have (or will add).

Add unit tests that construct a small DAG and verify the mergeset.

## Phase 3 – Scoped GHOSTDAG

Implement `ghostdag_scoped.rs` using the classic algorithm (you can port the logic from kovanica-dag or write a clean version).

Key function signature:

```rust
pub fn colour_mergeset(
    blocks: &[Block],
    k: usize,               // = 3
    previous_tips: &[BlockHash],
) -> ColouringResult
```

`ColouringResult` contains the blue-set and the selected-parent map.

## Phase 4 – Wire into the committer

Replace (or wrap) the current linearizer call inside the commit path:

```rust
// old
let ordered = linearizer.linearize(subdag);

// new
let mergeset = dag.mergeset(&leader_hash);
let colouring = colour_mergeset(&mergeset_blocks, 3, &previous_tips);
let ordered = colouring.blue_ordered();
```

Keep a feature flag:

```rust
if config.use_mysticghost {
    // scoped GHOSTDAG path
} else {
    // original linearizer (pure Mysticeti)
}
```

## Phase 5 – Tests & resource checks

1. Port / write the smoke test from `tests/mysticghost_smoke.rs`.
2. Run the full `kvnc-consensus` test suite.
3. Start a node with a memory limit (e.g. `systemd` MemoryMax=3G) and let it run for hours.
4. Measure RSS while generating load.

## Phase 6 – Pruning

Once colouring works, implement aggressive pruning:

- Discard non-blue blocks of a wave after the wave is committed.
- Discard whole waves older than `PRUNE_WINDOW` (suggested 100).

This is the main lever that keeps the node inside the 2–4 GB budget.

## Rollback plan

Because of the feature flag, you can always fall back to pure Mysticeti by setting `use_mysticghost = false`. No data migration is required for the consensus change itself.

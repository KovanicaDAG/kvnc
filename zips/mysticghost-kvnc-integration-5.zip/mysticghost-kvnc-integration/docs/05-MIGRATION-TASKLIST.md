# 05 – Migration Task List (MysticGhost on kvnc)

Work in strict order. Do not skip phases.

## Phase 0 – Production loop (must be done first)

- [ ] Votes reach the consensus engine in a running node
- [ ] `CommittedSubDag` is delivered to execution
- [ ] Rewards are credited correctly
- [ ] All existing `kvnc-consensus` tests green
- [ ] Single-node smoke test runs for ≥ 1 hour without crash

**Exit criteria:** You can see real commits and rewards on a live node.

## Phase 1 – Scaffolding

- [ ] Copy stub modules from this package
- [ ] Add `mod` declarations
- [ ] `cargo check -p kvnc-consensus` and `-p kvnc-dag` succeed
- [ ] Feature flag `use_mysticghost` exists (default false)

## Phase 2 – Mergeset

- [ ] Implement `mergeset(leader) -> Vec<BlockHash>`
- [ ] Unit tests with small synthetic DAGs
- [ ] Benchmark mergeset extraction on 1k–5k block DAGs

## Phase 3 – Scoped GHOSTDAG

- [ ] Implement `colour_mergeset(..., k=3)`
- [ ] Unit tests that verify blue-set is conflict-free
- [ ] Unit tests for selected-parent ordering
- [ ] Compare result with a known GHOSTDAG reference on a few fixtures

## Phase 4 – Committer integration

- [ ] Wire scoped colouring into the commit path behind the feature flag
- [ ] When flag is false → original linearizer (bit-identical behaviour)
- [ ] When flag is true → blue-set order is used
- [ ] Existing consensus tests still pass with flag = false
- [ ] New tests pass with flag = true

## Phase 5 – Resource hardening

- [ ] Implement pruning of non-blue blocks after commit
- [ ] Implement wave-window pruning (`prune_window_waves`)
- [ ] Add metrics (mergeset size, colouring time, blocks in memory, RSS)
- [ ] Run node under `MemoryMax=3G` for ≥ 6 hours with load
- [ ] Document observed RSS

## Phase 6 – Multi-node & stabilisation

- [ ] 4-node and 15-node local testnets
- [ ] Partition / recovery tests
- [ ] Long-running soak test (24 h+)
- [ ] Final resource report

## Phase 7 – Optional later work

- [ ] Port additional ledger features (if still desired)
- [ ] Light-client support for wave commits + colouring certificates
- [ ] Mainnet preparation

---

**Rule:** A phase is finished only when all its checkboxes are green and the resource budget is still respected.

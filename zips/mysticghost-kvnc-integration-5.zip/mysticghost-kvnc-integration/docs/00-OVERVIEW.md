# 00 – Overview: MysticGhost on kvnc

## Goal

Turn the existing Mysticeti-style uncertified DAG in `kvnc` into **MysticGhost**:

- Keep the wave structure (length = 3) and leader election.
- Replace (or augment) the current linearizer with **scoped GHOSTDAG k=3** that runs only on the mergeset of a newly committed leader.
- Preserve the low-resource target (comfortable on 2–4 GB RAM).
- Keep the existing account model + Wasmi execution path.

## Core Idea (one sentence)

When a leader is committed (direct or indirect), extract its mergeset and run classic GHOSTDAG k=3 **only on that mergeset**. The resulting blue-set becomes the canonical total order for that wave.

## What stays the same

- Wave length = 3
- Stake-weighted VRF leader selection
- Direct / Indirect commit rules
- Reward minted only on committed leaders
- Tokenomics (RFC-006 / kvnc TOKENOMICS.md)
- Account model + Wasmi
- libp2p networking

## What changes

| Component              | Current (kvnc)              | After MysticGhost                     |
|------------------------|-----------------------------|---------------------------------------|
| Ordering inside wave   | Linearizer (topological)    | Scoped GHOSTDAG k=3 blue-set          |
| Conflict resolution    | Implicit in linearizer      | Explicit blue/red colouring           |
| Safety argument        | Quorum only                 | Quorum + k-cluster property           |
| Pruning                | Basic                       | Aggressive (non-blue + old waves)     |

## Resource Philosophy

Every new data structure and algorithm must answer:

> “Does this keep a full node under 3 GB RAM with 21 validators and moderate load?”

If the answer is “maybe”, it is rejected or made optional.

## Success Criteria

- [ ] All existing kvnc-consensus tests still pass
- [ ] New MysticGhost unit + integration tests pass
- [ ] A single validator node runs stably under 2.5 GB RSS
- [ ] 15–21 validator testnet can be spun up on modest VPS instances
- [ ] CommittedSubDag still flows to execution exactly as today

# RFC-MG-001 (kvnc adaptation): MysticGhost Consensus

**Status:** Draft for kvnc  
**Author:** KovanicaDAG Core  
**Created:** 2026-10-07  
**Target repo:** KovanicaDAG/kvnc  
**Base:** existing Mysticeti-style engine (wave length 3)

---

## 1. Abstract

MysticGhost is a hybrid that keeps the Mysticeti wave engine already present in `kvnc-consensus` and adds a **scoped GHOSTDAG k=3** colouring step that runs only on the mergeset of a committed leader block.

The result is deterministic total ordering with stronger conflict resolution while preserving the low-latency wave commit path and the 2–4 GB resource target.

## 2. Motivation for kvnc

- The current linearizer gives a total order but has weaker explicit conflict handling.
- GHOSTDAG k=3 provides a well-understood blue-set / k-cluster safety property.
- Running GHOSTDAG only on the mergeset of one wave keeps CPU and memory cost low.
- The existing `CommittedSubDag` → execution path can stay unchanged.

## 3. Specification Summary

### 3.1 Wave structure (unchanged)

- Round 0: Leader proposal (VRF-selected)
- Round 1: Votes + ordinary blocks
- Round 2: Decide

### 3.2 Commit rules (unchanged)

- Direct: ≥ 2f+1 votes for the leader in its wave
- Indirect: later direct-committed leader references the earlier one via the DAG

### 3.3 New step – Scoped GHOSTDAG

When a leader `L` becomes committed:

1. Compute `mergeset(L)` = all blocks reachable from `L` that are not yet part of any previous `CommittedSubDag`.
2. Run GHOSTDAG colouring with parameter `k = 3` on the subgraph induced by `mergeset(L)` union the previous committed tips.
3. The blue-set of that colouring, ordered by the selected-parent relation, becomes the ordered list inside the new `CommittedSubDag`.

### 3.4 Compatibility

- Setting `GHOSTDAG_SCOPE = disabled` recovers pure Mysticeti behaviour (current linearizer).
- All existing tokenomics, staking and execution logic remains valid.

## 4. Resource Constraints (normative for kvnc)

- Full node must stay comfortable under 3 GB RSS with 21 validators.
- Mergeset size is expected to be small (hundreds of blocks, not the whole history).
- Non-blue blocks and fully committed waves older than a configurable window are pruned aggressively.

## 5. Implementation Notes

- Reuse the battle-tested GHOSTDAG logic from `kovanica-dag` (extract as a pure library crate if needed).
- The new code lives primarily in `kvnc-consensus`.
- No changes to the account model or Wasmi runtime are required for the consensus change itself.

## 6. Open Questions

1. Exact VRF parameters already chosen in kvnc – keep them.
2. Pruning window size (suggested default: 100 waves).
3. Whether to expose a “pure Mysticeti” compatibility flag long-term.

#!/usr/bin/env bash
# Helper script – copies the MysticGhost stubs into an existing kvnc tree.
# Usage (from the root of your kvnc repo):
#   /path/to/mysticghost-kvnc-integration/scripts/apply-stubs.sh

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "MysticGhost stub installer"
echo "Package root : $PKG_ROOT"
echo "Current dir  : $(pwd)"
echo

if [[ ! -d crates/kvnc-consensus/src ]]; then
    echo "ERROR: crates/kvnc-consensus/src not found."
    echo "Run this script from the root of your kvnc repository."
    exit 1
fi

echo "→ Copying consensus stubs..."
cp -v "$PKG_ROOT/crates/kvnc-consensus/src/mysticghost.rs"          crates/kvnc-consensus/src/
cp -v "$PKG_ROOT/crates/kvnc-consensus/src/ghostdag_scoped.rs"      crates/kvnc-consensus/src/
cp -v "$PKG_ROOT/crates/kvnc-consensus/src/committer_mysticghost.rs" crates/kvnc-consensus/src/

echo "→ Copying dag stubs..."
mkdir -p crates/kvnc-dag/src
cp -v "$PKG_ROOT/crates/kvnc-dag/src/mergeset.rs" crates/kvnc-dag/src/

echo
echo "Stubs copied."
echo
echo "Next steps:"
echo "  1. Add the new modules to lib.rs / mod.rs"
echo "  2. cargo check -p kvnc-consensus"
echo "  3. Follow docs/03-INTEGRATION-GUIDE.md and docs/05-MIGRATION-TASKLIST.md"
echo
echo "Remember: keep use_mysticghost = false until Phase 0 is fully green."

//! Mergeset extraction helper for MysticGhost.
//!
//! The mergeset of a committed leader is the set of all blocks that are
//! reachable from the leader and have not yet been included in any previous
//! CommittedSubDag.
//!
//! This module provides a clean API; the real implementation should reuse
//! the existing reachability / ancestor indexes of the DAG store.

use kvnc_types::BlockHash;
use std::collections::{HashSet, VecDeque};

/// Trait that the DAG store should implement (or already partially implements).
pub trait DagReachability {
    /// Returns true if `ancestor` is in the past cone of `block` (or equal).
    fn is_ancestor(&self, ancestor: &BlockHash, block: &BlockHash) -> bool;

    /// Direct parents of a block.
    fn parents(&self, block: &BlockHash) -> Vec<BlockHash>;

    /// All blocks that have already been committed in previous sub-dags.
    fn already_committed(&self) -> &HashSet<BlockHash>;
}

/// Compute the mergeset of `leader`.
///
/// Simple BFS / DFS implementation. For production, replace with an
/// indexed version that uses the reachability oracle.
pub fn compute_mergeset<D: DagReachability>(
    dag: &D,
    leader: &BlockHash,
) -> Vec<BlockHash> {
    let mut result = Vec::new();
    let mut visited = HashSet::new();
    let mut queue = VecDeque::new();

    queue.push_back(*leader);
    visited.insert(*leader);

    while let Some(current) = queue.pop_front() {
        if dag.already_committed().contains(&current) && current != *leader {
            // Do not cross into previously committed territory
            // (except the leader itself which is the root of this mergeset)
            continue;
        }

        result.push(current);

        for parent in dag.parents(&current) {
            if visited.insert(parent) {
                queue.push_back(parent);
            }
        }
    }

    // The classic mergeset also includes blocks that point *to* the leader
    // but are not yet committed. Depending on your exact DAG store API you
    // may need a second pass over children / tips. Adjust accordingly.
    result
}

#[cfg(test)]
mod tests {
    // Add synthetic DAG tests here once the real store is available.
}

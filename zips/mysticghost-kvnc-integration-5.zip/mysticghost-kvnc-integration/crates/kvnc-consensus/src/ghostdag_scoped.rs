//! Scoped GHOSTDAG k=3 colouring.
//!
//! Runs classic GHOSTDAG only on the mergeset of a newly committed leader.
//! This keeps CPU and memory cost proportional to wave size, not full history.

use kvnc_types::BlockHash;
use std::collections::{HashMap, HashSet};

/// Output of a scoped colouring run.
#[derive(Debug, Clone)]
pub struct ColouringResult {
    /// Blocks that were coloured blue (conflict-free set).
    pub blue: Vec<BlockHash>,
    /// Selected-parent relation for the blue blocks.
    pub selected_parent: HashMap<BlockHash, Option<BlockHash>>,
    /// Blue score of each blue block (useful for metrics / debugging).
    pub blue_score: HashMap<BlockHash, u64>,
}

impl ColouringResult {
    /// Returns the blue blocks in a deterministic topological order
    /// induced by the selected-parent relation.
    pub fn blue_ordered(&self) -> Vec<BlockHash> {
        // Simple implementation: Kahn-style or DFS following selected_parent.
        // Production code should use a proper topological sort that respects
        // the selected-parent tree + any remaining causal edges among blue blocks.
        let mut ordered = self.blue.clone();
        // TODO: replace with real topological order
        ordered.sort(); // placeholder – deterministic but not causal
        ordered
    }
}

/// Colour the given mergeset with GHOSTDAG parameter `k`.
///
/// `blocks` – the mergeset (and optionally previous tips already included)
/// `k`      – must be 3 for the current safety claims
/// `previous_tips` – tips of prior committed sub-dags (treated as already blue)
///
/// This is a **skeleton**. Replace the body with a real GHOSTDAG implementation
/// (you can port the logic from kovanica-dag or write a clean version).
pub fn colour_mergeset(
    blocks: &[kvnc_types::block::StatementBlock],
    k: usize,
    _previous_tips: &[BlockHash],
) -> ColouringResult {
    assert_eq!(k, 3, "MysticGhost currently requires k = 3");

    // ------------------------------------------------------------------
    // PLACEHOLDER IMPLEMENTATION
    // ------------------------------------------------------------------
    // Real implementation must:
    // 1. Build the induced subgraph of `blocks`
    // 2. Iterate blocks in some topological order
    // 3. For each block compute the largest blue anticone
    // 4. Colour blue iff that size ≤ k
    // 5. Choose selected parent = blue parent with highest blue-score
    //
    // Until the real algorithm is ported, we colour everything blue
    // so that the rest of the pipeline can be wired and tested.
    // ------------------------------------------------------------------

    let mut blue = Vec::new();
    let mut selected_parent = HashMap::new();
    let mut blue_score = HashMap::new();

    for (i, b) in blocks.iter().enumerate() {
        let hash = b.digest(); // adjust to your actual hash method
        blue.push(hash);
        selected_parent.insert(hash, None); // TODO: real selected parent
        blue_score.insert(hash, i as u64);
    }

    ColouringResult {
        blue,
        selected_parent,
        blue_score,
    }
}

// ---------------------------------------------------------------------------
// Future real implementation notes
// ---------------------------------------------------------------------------
//
// A minimal correct GHOSTDAG colouring looks roughly like:
//
// for block in topological_order(mergeset) {
//     let mut blue_anticone = HashSet::new();
//     for other in already_blue {
//         if !are_comparable(block, other) {
//             blue_anticone.insert(other);
//         }
//     }
//     if blue_anticone.len() <= k {
//         colour[block] = Blue;
//         selected_parent[block] = best_blue_parent(block);
//         blue_score[block] = blue_score[selected_parent] + 1 + mergeset_size(...);
//     } else {
//         colour[block] = Red;
//     }
// }
//
// You already have reachability / past-cone helpers in the DAG store –
// reuse them heavily.

//! Drop-in / wrapper committer that can use MysticGhost ordering.
//!
//! This file shows how to integrate the new path into the existing
//! UniversalCommitter without breaking the pure-Mysticeti mode.

use crate::mysticghost::{order_committed_wave, MysticGhostConfig, MysticGhostOrder};
use crate::ghostdag_scoped::ColouringResult;

/// Example of how the commit path should look after integration.
///
/// Pseudo-code – adapt to your real UniversalCommitter / Linearizer types.
pub fn commit_with_optional_mysticghost(
    cfg: &MysticGhostConfig,
    leader_hash: kvnc_types::BlockHash,
    // the DAG store that can answer mergeset()
    dag: &impl MergesetProvider,
    // the original linearizer (kept for fallback)
    linearizer: &impl LinearizerTrait,
    previous_tips: &[kvnc_types::BlockHash],
) -> Vec<kvnc_types::BlockHash> {
    // 1. Always compute the mergeset (cheap if the DAG store is indexed)
    let mergeset_hashes = dag.mergeset(&leader_hash);
    let mergeset_blocks = dag.get_blocks(&mergeset_hashes);

    // 2. Ask MysticGhost whether it wants to order this wave
    match order_committed_wave(cfg, &mergeset_blocks, previous_tips) {
        MysticGhostOrder::Ghost { colouring } => {
            // Use the blue-set order
            colouring.blue_ordered()
        }
        MysticGhostOrder::Fallback => {
            // Pure Mysticeti path – bit-identical to today
            linearizer.linearize(&mergeset_hashes)
        }
    }
}

// ---------------------------------------------------------------------------
// Traits you will need (add them to the appropriate place in kvnc-dag / consensus)
// ---------------------------------------------------------------------------

pub trait MergesetProvider {
    fn mergeset(&self, leader: &kvnc_types::BlockHash) -> Vec<kvnc_types::BlockHash>;
    fn get_blocks(&self, hashes: &[kvnc_types::BlockHash]) -> Vec<kvnc_types::block::StatementBlock>;
}

pub trait LinearizerTrait {
    fn linearize(&self, blocks: &[kvnc_types::BlockHash]) -> Vec<kvnc_types::BlockHash>;
}

# MysticGhost Integration Package for kvnc

**Version:** 0.1.0-draft  
**Date:** 2026-10-07  
**Target:** KovanicaDAG/kvnc (Mysticeti-style base)  
**Status:** Ready for slow-path integration

This package contains everything needed to evolve the current Mysticeti-style consensus in `kvnc` into **MysticGhost** (wave-based leader commit + scoped GHOSTDAG k=3 colouring).

## Why this package?

You chose the slower, cleaner path (kvnc) primarily for the low resource target (2–4 GB).  
This package is designed to keep that target while adding the hybrid consensus.

## Package Contents

```
mysticghost-kvnc-integration/
├── README.md                          ← this file
├── docs/
│   ├── 00-OVERVIEW.md                 ← high-level plan & principles
│   ├── 01-RFC-MG-001-adapted.md        ← RFC tailored for kvnc
│   ├── 02-FORMAL-SPEC.md              ← formal specification
│   ├── 03-INTEGRATION-GUIDE.md        ← step-by-step how to apply
│   ├── 04-RESOURCE-BUDGET.md          ← hard limits to protect 2–4 GB target
│   └── 05-MIGRATION-TASKLIST.md       ← phased task list
├── crates/
│   ├── kvnc-consensus/src/
│   │   ├── mysticghost.rs             ← new module (wave + GHOSTDAG glue)
│   │   ├── ghostdag_scoped.rs         ← scoped GHOSTDAG colouring
│   │   └── committer_mysticghost.rs   ← replacement for UniversalCommitter
│   └── kvnc-dag/src/
│       └── mergeset.rs                ← mergeset extraction helper
├── scripts/
│   └── apply-stubs.sh                 ← helper to copy stubs into your tree
└── tests/
    └── mysticghost_smoke.rs           ← basic unit-test skeleton
```

## Quick Start

1. Unzip this archive next to your `kvnc` repo (or inside it).
2. Read `docs/00-OVERVIEW.md` and `docs/03-INTEGRATION-GUIDE.md`.
3. Follow the phased task list in `docs/05-MIGRATION-TASKLIST.md`.
4. Keep the resource budget in `docs/04-RESOURCE-BUDGET.md` as a hard constraint.

## Design Principles (non-negotiable)

- **Resource first**: every change must be measurable against the 2–4 GB target.
- **Incremental**: pure Mysticeti remains a special case (GHOSTDAG scope can be disabled).
- **No rewrite of ledger**: keep the existing account + Wasmi path; only change how blocks are ordered/committed.
- **Test-driven**: every phase ends with green tests before moving on.

## Recommended Order of Work

1. Finish the current production consensus loop (CommittedSubDag must actually reach execution).
2. Add the scoped GHOSTDAG colouring (this package).
3. Wire wave-local GHOSTDAG into the committer.
4. Add resource guards and pruning.
5. Only then expand features (multi-asset, stealth, etc.).

---

Prepared for the slow, correct path.  
Good luck — keep the node under 3 GB.
